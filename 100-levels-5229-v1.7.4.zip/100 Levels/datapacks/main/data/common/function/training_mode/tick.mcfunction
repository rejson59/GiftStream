#check
execute as @a[team=training_mode,tag=!training_mode] run function common:training_mode/join
execute as @a[team=!training_mode,tag=training_mode] run function common:training_mode/leave

execute as @a[tag=enable_flight] run effect give @s invisibility infinite 255 true

execute as @a[team=training_mode] at @s run function common:training_mode/items/hotbar
execute as @a at @s run function common:training_mode/items/toggle_item


execute as @a[team=training_mode] at @s run function common:training_mode/timer/tick

execute as @a[team=training_mode] at @s run function common:training_mode/save_pos/tick with entity @s