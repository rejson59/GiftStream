execute if entity @a[distance=..40] unless entity @e[tag=end_elytra_item] run summon minecraft:item ~ ~ ~ {Tags:["end_elytra_item","ingame"],Item:{id:"minecraft:elytra"},PickupDelay:-9999}
execute as @e[tag=end_elytra_item] run data merge entity @s {PickupDelay:-9999}

execute unless entity @a[distance=..40] if entity @e[tag=end_elytra_item] run kill @e[tag=end_elytra_item]