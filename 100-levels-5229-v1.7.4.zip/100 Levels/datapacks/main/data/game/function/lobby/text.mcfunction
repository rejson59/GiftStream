kill @e[type=text_display]

summon text_display -74.0 129.1 -48.95 {text:[{"text":"Welcome to ","bold":false,"color":"white"},{"text":"100 Levels","color":"yellow","bold":true}],Rotation:[0.0f,0.0f],transformation:{scale:[0.8f,0.8f,0.8f],left_rotation:[0.0,0.0,0.0,1.0],right_rotation:[0.0,0.0,0.0,1.0],translation:[0.0,0.0,0.0]}}

summon text_display -74.0 128.5 -39 {text:[{"text":"Play!","color":"yellow","bold":true}],Rotation:[180.0f,0.0f],transformation:{scale:[0.8f,0.8f,0.8f],left_rotation:[0.0,0.0,0.0,1.0],right_rotation:[0.0,0.0,0.0,1.0],translation:[0.0,0.0,0.0]}}

summon text_display -79.95 128.5 -44 {text:{"text":"Sidebar","color":"white"},Rotation:[-90.0f,0.0f],transformation:{scale:[0.8f,0.8f,0.8f],left_rotation:[0.0,0.0,0.0,1.0],right_rotation:[0.0,0.0,0.0,1.0],translation:[0.0,0.0,0.0]}}

summon text_display -79.95 128.1 -44 {text:{"text":"Level","bold":true,"color":"yellow"},Rotation:[-90.0f,0.0f],transformation:{scale:[0.8f,0.8f,0.8f],left_rotation:[0.0,0.0,0.0,1.0],right_rotation:[0.0,0.0,0.0,1.0],translation:[0.0,0.0,0.0]},Tags:["lobby_lever_text"]}