tellraw @a[x=-80,y=128,z=-43,distance=..5] [{"text": "Level","color": "yellow","bold": true},{"text": " is now displayed in the tablist.","color": "gray","bold": false}]
scoreboard objectives setdisplay sidebar timer_sidebar
scoreboard objectives setdisplay list level
scoreboard players reset console timer_list
data merge entity @e[tag=lobby_lever_text,limit=1] {text:{"text":"Time","bold":true,"color":"yellow"}}