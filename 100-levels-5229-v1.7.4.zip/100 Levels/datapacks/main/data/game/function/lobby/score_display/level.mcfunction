tellraw @a[x=-80,y=128,z=-43,distance=..5] [{"text": "Time","color": "yellow","bold": true},{"text": " is now displayed in the tablist.","color": "gray","bold": false}]
scoreboard objectives setdisplay sidebar level
scoreboard objectives setdisplay list timer_sidebar
scoreboard players set console timer_list 1
data merge entity @e[tag=lobby_lever_text,limit=1] {text:{"text":"Level","bold":true,"color":"yellow"}}