tag @a remove lobby_indoor
execute as @a[x=-75,y=127,z=-38,dx=1,dy=2,dz=0] at @s run effect give @s nausea 5 255 true
execute as @a[x=-75,y=127,z=-38,dx=1,dy=2,dz=0] at @s run tag @s add lobby_indoor

execute as @a[tag=lobby_indoor] at @s run scoreboard players add @s lobby_door_timer 1
execute as @a[tag=!lobby_indoor,scores={lobby_door_timer=1..}] at @s run scoreboard players remove @s lobby_door_timer 1

execute as @a[tag=lobby_indoor,scores={lobby_door_timer=100..}] at @s run scoreboard players set @s start_timer 1

execute as @a if score @s start_timer matches 1.. run scoreboard players add @s start_timer 1
execute as @a if score @s start_timer matches 2..2 run tp @s -2 160 2 45.0 30.0
execute as @a if score @s start_timer matches 2..2 run effect clear @s nausea
execute as @a if score @s start_timer matches 2..2 run effect give @s slow_falling 4 1 true
execute as @a[scores={start_timer=10..10}] at @s run title @s times 0 60 20
execute as @a[scores={start_timer=10..10}] at @s run title @s title [{"text":"1","bold":true,"color":"white"}]
execute as @a[scores={start_timer=10..10}] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100000 0.5
execute as @a[scores={start_timer=15..15}] at @s run title @s title [{"text":"10","bold":true,"color":"white"}]
execute as @a[scores={start_timer=15..15}] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100000 0.5
execute as @a[scores={start_timer=20..20}] at @s run title @s title [{"text":"100","bold":true,"color":"white"}]
execute as @a[scores={start_timer=20..20}] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100000 0.5
execute as @a[scores={start_timer=25..25}] at @s run title @s title [{"text":"100 L","bold":true,"color":"white"}]
execute as @a[scores={start_timer=25..25}] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100000 0.5
execute as @a[scores={start_timer=30..30}] at @s run title @s title [{"text":"100 Le","bold":true,"color":"white"}]
execute as @a[scores={start_timer=30..30}] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100000 0.5
execute as @a[scores={start_timer=35..35}] at @s run title @s title [{"text":"100 Lev","bold":true,"color":"white"}]
execute as @a[scores={start_timer=35..35}] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100000 0.5
execute as @a[scores={start_timer=40..40}] at @s run title @s title [{"text":"100 Leve","bold":true,"color":"white"}]
execute as @a[scores={start_timer=40..40}] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100000 0.5
execute as @a[scores={start_timer=45..45}] at @s run title @s title [{"text":"100 Level","bold":true,"color":"white"}]
execute as @a[scores={start_timer=45..45}] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100000 0.5
execute as @a[scores={start_timer=50..50}] at @s run title @s title [{"text":"100 Levels","bold":true,"color":"white"}]
execute as @a[scores={start_timer=50..50}] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100000 0.5

execute as @a[scores={start_timer=60..}] run scoreboard players set @s start_timer 0