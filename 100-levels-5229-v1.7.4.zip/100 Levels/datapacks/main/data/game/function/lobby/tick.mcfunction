function game:lobby/start
function game:lobby/score_display/tick

data merge entity @e[tag=logo,limit=1,nbt=!{Item:{id:"minecraft:filled_map"}}] {Item:{count:1,id:"filled_map",components:{"minecraft:map_id":0}},ItemRotation:4b}
data merge entity @e[tag=logo,limit=1] {ItemRotation:4b}