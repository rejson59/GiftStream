scoreboard objectives add lv100timer dummy lv100timer
scoreboard objectives add lv100timer2 dummy lv100timer2
scoreboard objectives add lv100timer3 dummy lv100timer3
scoreboard objectives add lv20timer dummy lv20timer
scoreboard objectives add lv36timer dummy lv36timer
scoreboard objectives add lv36timer2 dummy lv36timer2
scoreboard objectives add lv37timer dummy lv37timer
scoreboard objectives add lv42timer dummy lv42timer
scoreboard objectives add lv46timer dummy lv46timer
scoreboard objectives add lv48timer dummy lv48timer
scoreboard objectives add lv57timer dummy lv57timer
scoreboard objectives add lv58timer dummy lv58timer
scoreboard objectives add lv58timer2 dummy lv58timer2
scoreboard objectives add lv58timer3 dummy lv58timer3
scoreboard objectives add lv61timer dummy lv61timer
scoreboard objectives add lv63timer dummy lv63timer
scoreboard objectives add lv64timer dummy lv64timer
scoreboard objectives add lv67timer dummy lv67timer
scoreboard objectives add lv69timer dummy lv69timer
scoreboard objectives add lv70timer dummy lv70timer
scoreboard objectives add lv75timer dummy lv75timer
scoreboard objectives add lv76timer dummy lv76timer
scoreboard objectives add lv76timer2 dummy lv76timer2
scoreboard objectives add lv78timer dummy lv78timer
scoreboard objectives add lv79skip dummy lv79skip
scoreboard objectives add lv79way1 dummy lv79way1
scoreboard objectives add lv79way2 dummy lv79way2
scoreboard objectives add lv79timer dummy lv79timer
scoreboard objectives add lv79timer2 dummy lv79timer2
scoreboard objectives add lv79timer3 dummy lv79timer3
scoreboard objectives add lv83timer dummy lv83timer
scoreboard objectives add lv84timer dummy lv84timer
scoreboard objectives add lv84timer2 dummy lv84timer2
scoreboard objectives add lv89piston dummy lv89piston
scoreboard objectives add lv89timer dummy lv89timer
scoreboard objectives add lv89timer2 dummy lv89timer2
scoreboard objectives add lv90timer dummy lv90timer
scoreboard objectives add lv91timer dummy lv91timer
scoreboard objectives add lv92timer dummy lv92timer
scoreboard objectives add lv93timer dummy lv93timer
scoreboard objectives add lv93timer2 dummy lv93timer2
scoreboard objectives add lv94timer dummy lv94timer
scoreboard objectives add lv96timer dummy lv96timer
scoreboard objectives add hp health hp

scoreboard objectives add level dummy {text:"Level",color:"yellow",bold:true}
scoreboard objectives add start_timer dummy start_timer
scoreboard objectives add lobby_door_timer dummy lobby_door_timer

scoreboard objectives add timer_list dummy timer_list

team add mob "mob"
team modify mob collisionRule never