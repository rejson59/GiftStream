execute as @a[x=-109,y=84,z=102,dx=0,dy=3,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-109,y=88,z=102,dx=0,dy=0,dz=0] at @s run effect clear @s
execute as @a[x=-109,y=85.5,z=102,distance=..20] run particle end_rod -109 85.5 102 0.1 1 0.1 0.02 1 normal

execute as @a[x=-109,y=83,z=106,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true

execute if block -123 87 106 lever[powered=true] run scoreboard players add console lv76timer 1
execute unless block -123 87 106 lever[powered=true] if score console lv76timer matches 1.. run scoreboard players remove console lv76timer 1

execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 10 run clone -114 50 104 -117 46 104 -118 81 107
execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 20 run clone -114 50 106 -117 46 106 -118 81 107
execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 30..30 run clone -114 50 108 -117 46 108 -118 81 107
execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 40..40 run clone -114 50 110 -117 46 110 -118 81 107
execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 50..50 run clone -114 50 112 -117 46 112 -118 81 107
execute if block -123 87 106 lever[powered=false] if score console lv76timer matches 10..10 run clone -114 50 102 -117 46 102 -118 81 107
execute if block -123 87 106 lever[powered=false] if score console lv76timer matches 20..20 run clone -114 50 104 -117 46 104 -118 81 107
execute if block -123 87 106 lever[powered=false] if score console lv76timer matches 30..30 run clone -114 50 106 -117 46 106 -118 81 107
execute if block -123 87 106 lever[powered=false] if score console lv76timer matches 40..40 run clone -114 50 108 -117 46 108 -118 81 107
execute if block -123 87 106 lever[powered=false] if score console lv76timer matches 50..50 run clone -114 50 110 -117 46 110 -118 81 107

execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 10..10 run playsound block.piston.extend master @a -116.0 81.5 107.5 1 1
execute unless block -123 87 106 lever[powered=true] if score console lv76timer matches 10..10 run playsound block.piston.contract master @a -116.0 81.5 107.5 1 1
execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 20..20 run playsound block.piston.extend master @a -116.0 81.5 107.5 1 1
execute unless block -123 87 106 lever[powered=true] if score console lv76timer matches 20..20 run playsound block.piston.contract master @a -116.0 81.5 107.5 1 1
execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 30..30 run playsound block.piston.extend master @a -116.0 81.5 107.5 1 1
execute unless block -123 87 106 lever[powered=true] if score console lv76timer matches 30..30 run playsound block.piston.contract master @a -116.0 81.5 107.5 1 1
execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 40..40 run playsound block.piston.extend master @a -116.0 81.5 107.5 1 1
execute unless block -123 87 106 lever[powered=true] if score console lv76timer matches 40..40 run playsound block.piston.contract master @a -116.0 81.5 107.5 1 1
execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 50..50 run playsound block.piston.extend master @a -116.0 81.5 107.5 1 1
execute unless block -123 87 106 lever[powered=true] if score console lv76timer matches 50..50 run playsound block.piston.contract master @a -116.0 81.5 107.5 1 1

execute if block -123 87 106 lever[powered=true] if score console lv76timer matches 100.. run setblock -123 87 106 lever[face=floor,facing=north,powered=false]

execute if block -113 83 110 oak_button[powered=true] unless score console lv76timer2 matches 1.. run scoreboard players set console lv76timer2 1
execute if score console lv76timer2 matches 1.. run scoreboard players add console lv76timer2 1
execute if score console lv76timer2 matches 1..60 run setblock -110 81 107 redstone_torch
execute unless score console lv76timer2 matches 1..60 run setblock -110 81 107 stone_bricks
execute if score console lv76timer2 matches 30..90 run setblock -111 83 106 redstone_torch
execute unless score console lv76timer2 matches 30..90 run setblock -111 83 106 stone_bricks
execute if score console lv76timer2 matches 60..120 run setblock -110 84 104 redstone_torch
execute unless score console lv76timer2 matches 60..120 run setblock -110 84 104 stone_bricks
execute if score console lv76timer2 matches 90..150 run setblock -111 85 106 redstone_torch
execute unless score console lv76timer2 matches 90..150 run setblock -111 85 106 stone_bricks
execute if score console lv76timer2 matches 120..180 run setblock -110 78 113 redstone_torch
execute unless score console lv76timer2 matches 120..180 run setblock -110 78 113 stone_bricks
execute if score console lv76timer2 matches 200.. run scoreboard players set console lv76timer2 0