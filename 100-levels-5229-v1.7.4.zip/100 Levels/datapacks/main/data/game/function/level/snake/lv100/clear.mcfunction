scoreboard players set @e[tag=lv100snake] lv100timer 0
execute as @e[tag=lv100snake] at @s run setblock ~ ~ ~ air
kill @e[tag=lv100snake]
schedule clear game:level/snake/lv100/move