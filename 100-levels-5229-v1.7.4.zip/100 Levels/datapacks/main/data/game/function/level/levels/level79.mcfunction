execute as @a[x=-68,y=40,z=110,dx=0,dy=30,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-68,y=71,z=110,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -68 55 110 0.1 7 0.1 0.02 3 normal

execute as @a[x=-69,y=79,z=122,dx=0,dy=5,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-68,y=83,z=122,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -69 81.5 122 0.1 1 0.1 0.02 1 normal

execute if block -68 83 122 birch_pressure_plate[powered=true] run fill -67 83 122 -67 84 122 air destroy
execute unless block -68 83 122 birch_pressure_plate[powered=true] run fill -67 83 122 -67 84 122 end_stone

execute if block -59 63 120 crimson_pressure_plate[powered=true] run scoreboard players set console lv79timer 80
execute if score console lv79timer matches 1.. run scoreboard players remove console lv79timer 1
execute if score console lv79timer matches 1.. run fill -55 53 112 -54 53 111 air destroy
execute unless score console lv79timer matches 1.. run fill -55 53 112 -54 53 111 slime_block replace

execute if block -65 79 120 birch_button[powered=true] run scoreboard players set console lv79timer2 40
execute if block -65 79 120 birch_button[powered=true] run scoreboard players set console lv79skip 1
execute if score console lv79timer2 matches 1.. run scoreboard players remove console lv79timer2 1
execute if score console lv79timer2 matches 1.. run fill -62 79 121 -62 80 121 air destroy
execute unless score console lv79timer2 matches 1.. run fill -62 79 121 -62 80 121 end_stone_bricks replace

execute as @a[x=-59,y=83,z=122,distance=..2] unless score console lv79timer3 matches 1.. run scoreboard players set console lv79timer3 142
execute if score console lv79timer3 matches 1.. run scoreboard players remove console lv79timer3 1
execute if score console lv79timer3 matches 141..141 run fill -55 83 120 -54 83 121 purple_stained_glass replace
execute if score console lv79timer3 matches 61..61 run fill -55 83 120 -54 83 121 air destroy
execute unless score console lv79skip matches 1 if score console lv79timer3 matches 121..121 run scoreboard players set console lv79way1 1
execute if score console lv79skip matches 1 if score console lv79timer3 matches 121..121 run scoreboard players set console lv79way2 1
execute if score console lv79skip matches 1 if score console lv79timer3 matches 121..121 run scoreboard players reset console lv79skip
execute if score console lv79way1 matches 1 if score console lv79timer3 matches 121..121 run fill -50 83 119 -49 83 120 magenta_stained_glass replace
execute if score console lv79way1 matches 1 if score console lv79timer3 matches 41..41 run fill -50 83 119 -49 83 120 air destroy
execute if score console lv79way1 matches 1 if score console lv79timer3 matches 101..101 run fill -47 83 114 -46 83 115 purple_stained_glass replace
execute if score console lv79way1 matches 1 if score console lv79timer3 matches 21..21 run fill -47 83 114 -46 83 115 air destroy
execute if score console lv79way1 matches 1 if score console lv79timer3 matches 81..81 run fill -46 83 109 -45 83 110 magenta_stained_glass replace
execute if score console lv79way1 matches 1 if score console lv79timer3 matches 1..1 run fill -46 83 109 -45 83 110 air destroy
execute if score console lv79way2 matches 1 if score console lv79timer3 matches 121..121 run fill -51 84 116 -50 84 117 magenta_stained_glass replace
execute if score console lv79way2 matches 1 if score console lv79timer3 matches 41..41 run fill -51 84 116 -50 84 117 air destroy
execute if score console lv79way2 matches 1 if score console lv79timer3 matches 101..101 run fill -53 85 111 -52 85 112 purple_stained_glass replace
execute if score console lv79way2 matches 1 if score console lv79timer3 matches 21..21 run fill -53 85 111 -52 85 112 air destroy
execute if score console lv79way2 matches 1 if score console lv79timer3 matches 81..81 run fill -58 85 110 -57 85 111 magenta_stained_glass replace
execute if score console lv79way2 matches 1 if score console lv79timer3 matches 1..1 run fill -58 85 110 -57 85 111 air destroy
execute if score console lv79way1 matches 1 if score console lv79timer3 matches 1..1 run scoreboard players reset console lv79way1
execute if score console lv79way2 matches 1 if score console lv79timer3 matches 1..1 run scoreboard players reset console lv79way2

execute as @a[x=-69,y=86,z=111,dx=0,dy=1,dz=0] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-69,y=86,z=111,dx=0,dy=1,dz=0] at @s run tp @s ~ ~ ~ 180.0 30.0

data merge block -69 86 111 {Age:-999999999}
data merge block -69 87 111 {Age:-999999999}