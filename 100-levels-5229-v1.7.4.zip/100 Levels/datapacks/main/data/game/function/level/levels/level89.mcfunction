execute if block -75 85 90 lever[powered=true] run scoreboard players add console lv89timer 1
execute unless block -75 85 90 lever[powered=true] run scoreboard players set console lv89timer 0
execute if score console lv89timer matches 100 run setblock -75 85 90 lever[facing=south,powered=false]

execute if block -73 85 90 lever[powered=true] run scoreboard players add console lv89timer2 1
execute unless block -73 85 90 lever[powered=true] run scoreboard players set console lv89timer2 0
execute if score console lv89timer2 matches 100 run setblock -73 85 90 lever[facing=south,powered=false]

scoreboard players set console lv89piston 0
execute if block -73 85 90 lever[powered=true] if block -75 85 90 lever[powered=true] run scoreboard players set console lv89piston 1
execute if score console lv89piston matches 1 run fill -70 81 94 -69 81 95 redstone_block
execute if score console lv89piston matches 0 run fill -70 81 94 -69 81 95 cyan_terracotta

execute as @a[x=-70,y=70,z=104,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true