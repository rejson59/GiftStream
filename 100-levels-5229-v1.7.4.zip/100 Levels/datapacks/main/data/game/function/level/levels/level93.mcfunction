execute if block -54 26 280 light_weighted_pressure_plate unless block -54 26 280 light_weighted_pressure_plate[power=0] run scoreboard players set console lv93timer 100
execute if score console lv93timer matches 100 run playsound entity.experience_orb.pickup master @a -54 26 280 1 1
execute if score console lv93timer matches 100 run setblock -54 26 280 air destroy
execute if score console lv93timer matches 1.. run scoreboard players remove console lv93timer 1
execute if score console lv93timer matches 21.. run fill -53 19 272 -52 19 273 moving_piston
execute if score console lv93timer matches 21.. run fill -53 18 272 -52 18 273 air destroy
execute unless score console lv93timer matches 21.. run fill -53 19 272 -52 19 273 lava
execute unless score console lv93timer matches 21.. run fill -53 18 272 -52 18 273 netherrack
execute if score console lv93timer matches 0 run setblock -54 26 280 light_weighted_pressure_plate

execute if block -55 27 269 light_weighted_pressure_plate unless block -55 27 269 light_weighted_pressure_plate[power=0] run scoreboard players set console lv93timer2 100
execute if score console lv93timer2 matches 100..100 run playsound entity.experience_orb.pickup master @a -55 27 269 1 1
execute if score console lv93timer2 matches 100..100 run setblock -55 27 269 air destroy
execute if score console lv93timer2 matches 1.. run scoreboard players remove console lv93timer2 1
execute if score console lv93timer2 matches 21.. run fill -55 19 276 -54 19 277 moving_piston
execute if score console lv93timer2 matches 21.. run fill -55 18 276 -54 18 277 air destroy
execute unless score console lv93timer2 matches 21.. run fill -55 19 276 -54 19 277 lava
execute unless score console lv93timer2 matches 21.. run fill -55 18 276 -54 18 277 netherrack
execute if score console lv93timer2 matches 0..0 run setblock -55 27 269 light_weighted_pressure_plate

execute as @a[x=-55,y=18,z=276,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-53,y=18,z=272,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-39,y=16,z=273,dx=0,dy=14,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-39,y=31,z=273,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -39 23 273 0.1 4 0.1 0.02 1 normal