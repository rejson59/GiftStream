execute as @a[x=-59,y=9,z=327,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-54,y=16,z=328,dx=0,dy=6,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-54,y=23,z=328,dx=1,dy=0,dz=1] at @s run effect clear @s
particle end_rod -54 19.5 328 0.1 1.5 0.1 0.02 1 normal