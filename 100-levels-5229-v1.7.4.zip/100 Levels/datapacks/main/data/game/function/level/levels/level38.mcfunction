effect give @a[x=-6,y=90,z=48,dx=0,dy=5,dz=0] levitation 1 10 true
effect clear @a[x=-6,y=94,z=49,dx=0,dy=1,dz=0] levitation
particle end_rod -6 93 48 0.1 1.5 0.1 0.02 1 normal

execute as @a[x=-9,y=95,z=48,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true