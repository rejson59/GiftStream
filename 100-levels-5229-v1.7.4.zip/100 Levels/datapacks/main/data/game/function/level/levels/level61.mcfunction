execute as @a[x=-28,y=90,z=135,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-28,y=87,z=126,dx=0,dy=6,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-28,y=93,z=127,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -28 91 126 0.1 1.5 0.1 0.02 1 normal

execute if score console lv61timer matches 1.. run scoreboard players remove console lv61timer 1
execute unless score console lv61timer matches 1.. if block -23 85 131 crimson_button[powered=true] run playsound entity.experience_orb.pickup master @a -23 85 131 2 1 1
execute unless score console lv61timer matches 1.. if block -23 85 131 crimson_button[powered=true] run scoreboard players set console lv61timer 140
execute if score console lv61timer matches 1.. run setblock -27 89 126 redstone_lamp[lit=true] replace
execute unless score console lv61timer matches 1.. run setblock -27 89 126 redstone_lamp[lit=false] replace
execute if entity @a[x=-26,y=87,z=126,distance=..1.8] unless score console lv61timer matches 1.. run setblock -27 85 126 air
execute unless entity @a[x=-26,y=87,z=126,distance=..1.8] unless score console lv61timer matches 1.. run setblock -27 85 126 redstone_torch
execute if score console lv61timer matches 1.. run setblock -27 85 126 redstone_torch