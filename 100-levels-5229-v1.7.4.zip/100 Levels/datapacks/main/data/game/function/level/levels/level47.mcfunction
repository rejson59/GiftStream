execute as @a[x=-110,y=90,z=13,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true
execute as @a[x=-110,y=80,z=23,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-123,y=83,z=12,dx=4,dy=0.5,dz=3] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-123,y=83,z=12,dx=4,dy=0.5,dz=3] at @s run tp @s -119 90 17 90.0 30.0

execute as @a[x=-123,y=69,z=12,dx=6,dy=0,dz=3] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-123,y=69,z=12,dx=6,dy=0,dz=3] at @s run tp @s -122 73 17 -160.0 30.0

execute as @a[x=-113,y=74,z=13,dx=0,dy=11,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-113,y=86,z=13,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -113 80 13 0.1 2.5 0.1 0.02 1 normal