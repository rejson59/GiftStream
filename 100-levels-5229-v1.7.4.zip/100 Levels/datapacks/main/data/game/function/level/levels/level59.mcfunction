execute as @a[x=-63,y=79,z=126,dx=0,dy=7,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-63,y=87,z=126,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -63 83 126 0.1 1.75 0.1 0.02 1 normal