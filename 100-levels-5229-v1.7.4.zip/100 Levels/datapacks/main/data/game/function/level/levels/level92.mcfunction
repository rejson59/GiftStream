execute if block -22 26 283 birch_pressure_plate[powered=true] run scoreboard players set console lv92timer 122
execute if score console lv92timer matches 1.. if block -22 26 283 birch_pressure_plate run setblock -22 26 283 air destroy
execute unless score console lv92timer matches 1.. if block -22 26 283 air run setblock -22 26 283 birch_pressure_plate
execute if score console lv92timer matches 122..122 run setblock -19 23 281 bone_block[axis=y] replace
execute if score console lv92timer matches 122..122 run playsound block.bone_block.place master @a -19 23 281 1 1
execute if score console lv92timer matches 119..119 run setblock -19 23 280 bone_block[axis=z] replace
execute if score console lv92timer matches 119..119 run playsound block.bone_block.place master @a -19 23 280 1 1
execute if score console lv92timer matches 116..116 run setblock -19 24 280 bone_block[axis=y] replace
execute if score console lv92timer matches 116..116 run playsound block.bone_block.place master @a -19 24 280 1 1
execute if score console lv92timer matches 113..113 run setblock -19 25 280 bone_block[axis=y] replace
execute if score console lv92timer matches 113..113 run playsound block.bone_block.place master @a -19 25 280 1 1
execute if score console lv92timer matches 30..30 run setblock -19 25 280 air destroy
execute if score console lv92timer matches 26..26 run setblock -19 24 280 air destroy
execute if score console lv92timer matches 23..23 run setblock -19 23 280 air destroy
execute if score console lv92timer matches 21..21 run setblock -19 23 281 air destroy
execute if score console lv92timer matches 1.. run scoreboard players remove console lv92timer 1