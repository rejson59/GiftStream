execute as @a[x=-148,y=81,z=1,dx=18,dy=0.5,dz=9] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-148,y=81,z=1,dx=18,dy=0.5,dz=9] at @s if block ~ ~-1 ~ black_concrete run tp @s -129.5 83.5 2.5 18.0 30.0

effect give @a[x=-146,y=83,z=9,dx=0,dy=6,dz=0] levitation 1 10 true
effect clear @a[x=-146,y=90,z=9,dx=0,dy=0,dz=0] levitation
particle end_rod -146 86 9 0.1 1.5 0.1 0.02 1 normal