execute as @a[x=-10,y=50,z=123,dx=0,dy=1,dz=0] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-10,y=50,z=123,dx=0,dy=1,dz=0] at @s run tp @s ~ ~ ~ -90.0 30.0

data merge block -10 50 123 {Age:-999999999}
data merge block -10 51 123 {Age:-999999999}