execute as @a[x=-95,y=90,z=27,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-96,y=72,z=26,dx=15,dy=0,dz=15] at @s if block ~ ~ ~ water run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-96,y=72,z=26,dx=15,dy=0,dz=15] at @s if block ~ ~ ~ water run tp @s -81 73 40 83.0 30.0
execute as @a[x=-96,y=72,z=26,dx=15,dy=0,dz=15] at @s if block ~ ~ ~ seagrass run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-96,y=72,z=26,dx=15,dy=0,dz=15] at @s if block ~ ~ ~ seagrass run tp @s -81 73 40 83.0 30.0