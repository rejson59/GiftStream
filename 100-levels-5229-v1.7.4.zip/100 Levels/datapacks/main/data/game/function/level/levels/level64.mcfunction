execute if score console lv64timer matches 1.. run scoreboard players remove console lv64timer 1
execute if score console lv64timer matches 99..99 run playsound block.lava.extinguish master @a -18 85 85 2 1
execute if block -16 96 81 birch_pressure_plate[powered=true] run scoreboard players set console lv64timer 100
execute if block -16 96 81 birch_pressure_plate[powered=true] run setblock -16 96 81 air destroy
execute if score console lv64timer matches 1.. run fill -18 79 84 -19 82 83 moving_piston
execute unless score console lv64timer matches 1.. run fill -18 79 84 -19 82 83 lava
execute unless score console lv64timer matches 1.. run setblock -16 96 81 birch_pressure_plate

execute as @a[x=-19,y=81,z=83,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true