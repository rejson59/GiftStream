#execute unless entity @e[tag=lv94slime] run summon minecraft:magma_cube -78.0 19.7 273.0 {Tags:["lv94slime"],Invulnerable:1b,PersistenceRequired:1b,Silent:1b,NoGravity:0b,NoAI:1b,Size:4}
execute as @e[type=magma_cube,x=-78.0,y=19.5,z=273.0,distance=..3,tag=!lv94slime] at @s run kill @s
team join mob @e[tag=lv94slime]
effect give @e[tag=lv94slime] slowness 99999 255 true

execute if block -80 27 278 light_weighted_pressure_plate unless block -80 27 278 light_weighted_pressure_plate[power=0] unless score console lv94timer matches 1.. run scoreboard players set console lv94timer 1
execute if score console lv94timer matches 1.. run fill -78 21 272 -79 20 273 moving_piston
execute unless score console lv94timer matches 1.. run fill -78 21 272 -79 20 273 slime_block
execute if score console lv94timer matches 1..1 run data merge entity @e[tag=lv94slime,limit=1] {NoAI:0b}
execute if score console lv94timer matches 5..5 run data merge entity @e[tag=lv94slime,limit=1] {Motion:[0.0d,2.5d,0.0d]}
execute if score console lv94timer matches 60..60 run data merge entity @e[tag=lv94slime,limit=1] {NoAI:1b}
execute if score console lv94timer matches 60..60 run tp @e[tag=lv94slime] -78.0 19.7 273.0 -90.0 0.0
execute if score console lv94timer matches 90.. run scoreboard players set console lv94timer 0
execute if score console lv94timer matches 1.. run scoreboard players add console lv94timer 1

execute as @a[x=-79,y=18,z=272,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true