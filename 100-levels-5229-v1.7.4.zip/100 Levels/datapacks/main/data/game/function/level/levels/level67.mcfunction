execute as @a[x=-22,y=72,z=37,dx=0,dy=5,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-22,y=78,z=37,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -22 75 37 0.1 1.5 0.1 0.02 1 normal

execute unless entity @a[x=-19,y=82,z=29,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -22 82 29 stone
execute as @a[x=-19,y=82,z=29,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -22 82 29 redstone_torch

execute if score console lv67timer matches 1.. run scoreboard players remove console lv67timer 1
execute as @e[type=minecart,x=-19,y=82,z=29,distance=..1] run scoreboard players set console lv67timer 50
execute if entity @a[x=-19,y=82,z=29,distance=..10] unless score console lv67timer matches 1.. run summon minecart -19 82 29 {Tags:["lv67minecart"]}

execute as @e[type=minecart,tag=lv67minecart,x=-19,y=82,z=29,distance=1..] at @s unless entity @a[distance=..1,nbt={RootVehicle:{Entity:{id:"minecraft:minecart",Tags:["lv67minecart"]}}}] run kill @s
execute as @e[type=minecart,tag=lv67minecart] at @s unless entity @a[distance=..10] run kill @s