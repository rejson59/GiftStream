execute unless entity @a[x=-122,y=90,z=90,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -122 88 90 smooth_sandstone
execute as @a[x=-122,y=90,z=90,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -122 88 90 redstone_torch

execute if score console lv75timer matches 1.. run scoreboard players remove console lv75timer 1
execute as @e[type=minecart,x=-122,y=90,z=90,distance=..1] run scoreboard players set console lv75timer 50
execute if entity @a[x=-122,y=90,z=90,distance=..10] unless score console lv75timer matches 1.. run summon minecart -122 90 90 {Tags:["lv75minecart"]}

execute as @e[type=minecart,tag=lv75minecart,x=-122,y=90,z=90,distance=1..] at @s unless entity @a[distance=..1,nbt={RootVehicle:{Entity:{id:"minecraft:minecart",Tags:["lv75minecart"]}}}] run kill @s
execute as @e[type=minecart,tag=lv75minecart] at @s unless entity @a[distance=..10] run kill @s