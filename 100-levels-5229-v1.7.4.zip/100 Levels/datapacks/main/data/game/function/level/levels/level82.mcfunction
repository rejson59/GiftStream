execute as @a[x=-28,y=85,z=66,dx=0,dy=6,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-29,y=90,z=66,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -28 88 66 0.1 1.5 0.1 0.02 1 normal

execute as @a[x=-40,y=85,z=65,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true