execute if block -66 24 49 birch_pressure_plate[powered=true] unless score console lv84timer matches 1.. run scoreboard players set console lv84timer 221
execute if score console lv84timer matches 1.. run setblock -66 24 49 air destroy
execute unless score console lv84timer matches 1.. run setblock -66 24 49 birch_pressure_plate replace
execute if score console lv84timer matches 221 run clone -61 32 46 -61 33 46 -65 23 52
execute if score console lv84timer matches 221 run playsound block.sand.place master @a -65 23 52 2 1
execute if score console lv84timer matches 201 run clone -61 32 46 -61 33 46 -62 24 54
execute if score console lv84timer matches 201 run playsound block.sand.place master @a -62 24 54 2 1
execute if score console lv84timer matches 181 run clone -61 32 46 -61 33 46 -59 25 55
execute if score console lv84timer matches 181 run playsound block.sand.place master @a -59 25 55 2 1
execute if score console lv84timer matches 161 run clone -61 32 46 -61 33 46 -57 26 52
execute if score console lv84timer matches 161 run playsound block.sand.place master @a -57 26 52 2 1
execute if score console lv84timer matches 141 run clone -61 32 46 -61 33 46 -56 27 49
execute if score console lv84timer matches 141 run playsound block.sand.place master @a -56 27 49 2 1
execute if score console lv84timer matches 101 run setblock -65 23 52 air
execute if score console lv84timer matches 81 run setblock -62 24 54 air
execute if score console lv84timer matches 61 run setblock -59 25 55 air
execute if score console lv84timer matches 41 run setblock -57 26 52 air
execute if score console lv84timer matches 21 run setblock -56 27 49 air
execute if score console lv84timer matches 1.. run scoreboard players remove console lv84timer 1

execute unless entity @a[x=-49,y=60,z=44,distance=..10] run kill @e[tag=lv84elytra]
execute as @a[x=-49,y=60,z=44,distance=..10] unless entity @e[tag=lv84elytra] run summon minecraft:item -49 60.0 44 {Tags:["lv84elytra","ingame"],Item:{id:"minecraft:elytra"},PickupDelay:-32767}
execute as @e[tag=lv84elytra] at @s run data merge entity @s {PickupDelay:32767}
execute as @a[x=-49,y=60,z=44,distance=..1] at @s unless items entity @s armor.chest elytra run item replace entity @s armor.chest with minecraft:elytra[unbreakable={},tooltip_display={hidden_components:["unbreakable","enchantments"]},enchantment_glint_override=false,enchantments={"minecraft:binding_curse":1}]
execute as @a[x=-66,y=55,z=45,distance=..3] at @s run clear @s elytra

execute if block -59 34 47 birch_pressure_plate[powered=true] unless score console lv84timer2 matches 1.. run scoreboard players set console lv84timer2 60
execute if score console lv84timer2 matches 1.. run setblock -59 34 47 air destroy
execute if score console lv84timer2 matches 1.. run fill -52 22 49 -51 22 49 slime_block
execute unless score console lv84timer2 matches 1.. run setblock -59 34 47 birch_pressure_plate replace
execute unless score console lv84timer2 matches 1.. run fill -52 22 49 -51 22 49 snow_block
execute if score console lv84timer2 matches 1.. run scoreboard players remove console lv84timer2 1