execute as @a[x=-106,y=64,z=108,dx=17,dy=3,dz=15] at @s if block ~ ~ ~ water run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1 1
execute as @a[x=-106,y=64,z=108,dx=17,dy=3,dz=15] at @s if block ~ ~ ~ water run tp @s -106 69 121 -65.0 30.0

execute as @a[x=-105,y=89,z=108,dx=1,dy=1,dz=0] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1 1
execute as @a[x=-105,y=89,z=108,dx=1,dy=1,dz=0] at @s run tp @s ~ ~ ~ -60.0 30.0

data merge block -104 89 108 {Age:-999999999}
data merge block -104 90 108 {Age:-999999999}
data merge block -105 89 108 {Age:-999999999}
data merge block -105 90 108 {Age:-999999999}