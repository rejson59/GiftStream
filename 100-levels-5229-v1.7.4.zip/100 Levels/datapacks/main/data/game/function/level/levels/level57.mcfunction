execute if block -108 75 130 birch_pressure_plate[powered=true] run scoreboard players set console lv57timer 60
execute if score console lv57timer matches 1.. run scoreboard players remove console lv57timer 1
execute if score console lv57timer matches 1.. unless block -106 71 126 slime_block run setblock -106 71 126 slime_block destroy
execute if score console lv57timer matches 1.. unless block -108 75 130 air run setblock -108 75 130 air destroy
execute unless score console lv57timer matches 1.. run setblock -106 71 126 lime_concrete_powder
execute unless score console lv57timer matches 1.. run setblock -108 75 130 birch_pressure_plate