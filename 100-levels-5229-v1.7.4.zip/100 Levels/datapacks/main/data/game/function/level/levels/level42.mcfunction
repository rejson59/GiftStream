effect give @a[x=-27,y=92,z=13,dx=0,dy=0,dz=0] slow_falling 1 1 true

execute as @a[x=-27,y=38,z=13,dx=0,dy=8,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-27,y=47,z=13,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -27 42.5 13 0.1 1.6 0.1 0.02 1 normal

execute as @a[x=-44,y=66,z=18,dx=0,dy=24,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-44,y=89,z=19,dx=0,dy=2,dz=0] at @s run effect clear @s
particle end_rod -44 78 18 0.1 6 0.1 0.02 2 normal

execute unless entity @a[x=-36,y=49,z=22,distance=..4] run setblock -36 48 22 farmland
execute unless entity @a[x=-36,y=49,z=22,distance=..4] run setblock -36 49 22 wheat[age=7]
execute positioned -36 49 22 if entity @a[x=-36,y=49,z=22,distance=..4] unless block ~ ~ ~ hay_block run playsound block.grass.place master @a ~ ~ ~ 1 1
execute positioned -36 49 22 if entity @a[x=-36,y=49,z=22,distance=..4] unless block ~ ~ ~ hay_block run particle happy_villager ~ ~ ~ 0.5 0.5 0.5 0.3 30
execute positioned -36 49 22 if entity @a[x=-36,y=49,z=22,distance=..4] unless block ~ ~ ~ hay_block run setblock -36 49 22 hay_block

execute if block -27 46 15 stone_button[powered=true] run scoreboard players set console lv42timer 40
execute as @a[x=-30,y=47,z=20,dx=0,dy=1,dz=0] run scoreboard players set console lv42timer 40
execute if score console lv42timer matches 1.. run scoreboard players remove console lv42timer 1
execute if score console lv42timer matches 1.. run fill -30 47 19 -30 48 19 air destroy
execute unless score console lv42timer matches 1.. run fill -30 47 19 -30 48 19 stone replace

execute as @a[x=-30,y=47,z=22,dx=0,dy=1,dz=0] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-30,y=47,z=22,dx=0,dy=1,dz=0] at @s run tp @s ~ ~ ~ -144.6 30.0

data merge block -30 47 22 {Age:-999999999}
data merge block -30 48 22 {Age:-999999999}