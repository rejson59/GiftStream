execute unless entity @a[x=-96,y=90,z=58,distance=..10] if entity @e[tag=lv86elytra] run kill @e[tag=lv86elytra]
execute if entity @a[x=-96,y=90,z=58,distance=..10] unless entity @e[tag=lv86elytra] run summon minecraft:item -96 90 58 {Tags:["lv86elytra","ingame"],Item:{id:"minecraft:elytra"},PickupDelay:-9999}
execute as @e[tag=lv86elytra] run data merge entity @s {PickupDelay:-9999}

execute as @a[x=-96,y=90,z=58,distance=..1] at @s unless items entity @s armor.chest elytra run item replace entity @s armor.chest with minecraft:elytra[unbreakable={},tooltip_display={hidden_components:["unbreakable","enchantments"]},enchantment_glint_override=false,enchantments={"minecraft:binding_curse":1}]
execute as @a[x=-105,y=88,z=44,distance=..3] at @s run clear @s elytra
execute as @a[x=-105,y=90,z=59,dx=1,dy=0,dz=1] at @s run clear @s elytra
execute as @a[x=-105,y=70,z=59,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true