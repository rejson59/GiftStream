execute as @a[x=-24,y=80,z=12,dx=12,dy=10,dz=12] at @s if block ~ ~ ~ water run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-24,y=80,z=12,dx=12,dy=10,dz=12] at @s if block ~ ~ ~ water run tp @s -12 94 17 104.4 30.0
execute as @a[x=-24,y=80,z=12,dx=12,dy=10,dz=12] at @s if block ~ ~ ~ seagrass run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-24,y=80,z=12,dx=12,dy=10,dz=12] at @s if block ~ ~ ~ seagrass run tp @s -12 94 17 104.4 30.0

execute if block -22 86 14 stone_button[powered=true] run fill -19 86 15 -20 86 16 air destroy
execute unless block -22 86 14 stone_button[powered=true] run fill -19 86 15 -20 86 16 slime_block replace

execute as @a[x=-20,y=40,z=15,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true