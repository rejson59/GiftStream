execute as @a[x=-109,y=80,z=44,dx=0,dy=4,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-109,y=85,z=44,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -109 82 44 0.1 1.2 0.1 0.02 1 normal

execute as @a[x=-108,y=80,z=58,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 2 1 true