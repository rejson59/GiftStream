execute as @a[x=-83,y=63,z=108,dx=0,dy=5,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-83,y=67,z=109,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -83 67 108 0.1 1.5 0.1 0.02 1 normal

execute as @a[x=-87,y=94,z=108,dx=1,dy=0,dz=1] at @s run effect give @s levitation 9999 12 true
execute as @a[x=-73,y=96,z=122,distance=..2] at @s run effect clear @s levitation
particle end_rod -86.0 95.0 109.0 0.6 0.4 0.6 0.02 1 normal

execute if score console lv78timer matches 1..600 run scoreboard players add console lv78timer 1
execute as @a[x=-79,y=44,z=113,distance=..3] unless score console lv78timer matches 1.. run scoreboard players set console lv78timer 1
execute unless entity @a[x=-87,y=45,z=108,dx=15,dy=32,dz=15,distance=7..,tag=!dead,tag=!tolv79] if score console lv78timer matches 1.. run scoreboard players set console lv78timer 0
execute if score console lv78timer matches 1 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run title @s clear
execute if score console lv78timer matches 1..1 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run title @s times 0 30 10
execute if score console lv78timer matches 1..1 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run title @s title [{"text":"5","color":"gray","bold":true}]
execute if score console lv78timer matches 1..1 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run playsound block.note_block.harp master @s ~ ~ ~ 9999 1 1
execute if score console lv78timer matches 21..21 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run title @s title [{"text":"4","color":"gray","bold":true}]
execute if score console lv78timer matches 21..21 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run playsound block.note_block.harp master @s ~ ~ ~ 9999 1 1
execute if score console lv78timer matches 41..41 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run title @s title [{"text":"3","color":"green","bold":true}]
execute if score console lv78timer matches 41..41 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run playsound block.note_block.harp master @s ~ ~ ~ 9999 1 1
execute if score console lv78timer matches 61..61 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run title @s title [{"text":"2","color":"yellow","bold":true}]
execute if score console lv78timer matches 61..61 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run playsound block.note_block.harp master @s ~ ~ ~ 9999 1 1
execute if score console lv78timer matches 81..81 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run title @s title [{"text":"1","color":"red","bold":true}]
execute if score console lv78timer matches 81..81 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run playsound block.note_block.harp master @s ~ ~ ~ 9999 1 1 
execute if score console lv78timer matches 101..101 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run title @s title [{"text":"Lava is rising!","color":"red","bold":true,"underlined":true}]
execute if score console lv78timer matches 101..101 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run title @s times 10 70 20
execute if score console lv78timer matches 101..101 as @a[x=-87,y=45,z=108,dx=15,dy=36,dz=15,distance=7..] at @s run playsound block.note_block.harp master @s ~ ~ ~ 9999 2 1

execute if score console lv78timer matches 0 if block -83 44 112 lava run fill -87 44 108 -72 77 123 air replace lava
execute if score console lv78timer matches 111..111 run fill -87 44 108 -72 44 123 lava replace air
execute if score console lv78timer matches 131..131 run fill -87 45 108 -72 45 123 lava replace air
execute if score console lv78timer matches 151..151 run fill -85 46 110 -72 46 123 lava replace air
execute if score console lv78timer matches 171..171 run fill -85 47 110 -72 47 123 lava replace air
execute if score console lv78timer matches 191..191 run fill -85 48 110 -72 48 123 lava replace air
execute if score console lv78timer matches 211..211 run fill -85 49 110 -72 49 123 lava replace air
execute if score console lv78timer matches 226..226 run fill -87 50 108 -72 50 123 lava replace air
execute if score console lv78timer matches 241..241 run fill -87 51 108 -72 51 123 lava replace air
execute if score console lv78timer matches 256..256 run fill -87 52 108 -72 52 123 lava replace air
execute if score console lv78timer matches 271..271 run fill -87 53 108 -72 53 123 lava replace air
execute if score console lv78timer matches 286..286 run fill -87 54 108 -72 54 123 lava replace air
execute if score console lv78timer matches 301..301 run fill -87 55 108 -72 55 123 lava replace air
execute if score console lv78timer matches 316..316 run fill -87 56 108 -72 56 123 lava replace air
execute if score console lv78timer matches 331..331 run fill -87 57 108 -72 57 123 lava replace air
execute if score console lv78timer matches 346..346 run fill -87 58 108 -72 58 123 lava replace air
execute if score console lv78timer matches 361..361 run fill -87 59 108 -72 59 123 lava replace air
execute if score console lv78timer matches 376..376 run fill -87 60 108 -72 60 123 lava replace air
execute if score console lv78timer matches 391..391 run fill -87 61 108 -72 61 123 lava replace air
execute if score console lv78timer matches 401..401 run fill -87 62 108 -72 62 123 lava replace air
execute if score console lv78timer matches 411..411 run fill -87 63 108 -72 63 123 lava replace air
execute if score console lv78timer matches 421..421 run fill -87 64 108 -72 64 123 lava replace air
execute if score console lv78timer matches 431..431 run fill -87 65 108 -72 65 123 lava replace air
execute if score console lv78timer matches 441..441 run fill -87 66 108 -72 66 123 lava replace air
execute if score console lv78timer matches 451..451 run fill -87 67 108 -72 67 123 lava replace air
execute if score console lv78timer matches 461..461 run fill -87 68 108 -72 68 123 lava replace air
execute if score console lv78timer matches 471..471 run fill -87 69 108 -72 69 123 lava replace air
execute if score console lv78timer matches 481..481 run fill -87 70 108 -72 70 123 lava replace air
execute if score console lv78timer matches 491..491 run fill -87 71 108 -72 71 123 lava replace air
execute if score console lv78timer matches 501..501 run fill -87 72 108 -72 72 123 lava replace air
execute if score console lv78timer matches 511..511 run fill -87 73 108 -72 73 123 lava replace air
execute if score console lv78timer matches 521..521 run fill -87 74 108 -72 74 123 lava replace air
execute if score console lv78timer matches 531..531 run fill -87 75 108 -72 75 123 lava replace air
execute if score console lv78timer matches 541..541 run fill -87 76 108 -72 76 123 lava replace air
execute if score console lv78timer matches 551..551 run fill -87 77 108 -72 77 123 lava replace air

tag @a remove tolv79
tag @a[x=-73,y=50,z=122,dx=0,dy=45,dz=0] add tolv79