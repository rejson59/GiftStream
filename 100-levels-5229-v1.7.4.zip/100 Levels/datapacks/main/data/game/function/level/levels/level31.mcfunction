execute as @a[x=-17,y=90,z=140,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-18,y=83,z=139,dx=17,dy=0.5,dz=9] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-18,y=83,z=139,dx=17,dy=0.5,dz=9] at @s run tp @s -16 85 141 0.0 30.0

execute as @a[x=-9,y=85,z=140,dx=0,dy=9,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-9,y=95,z=140,dx=0,dy=0,dz=0] at @s run effect clear @s
execute as @a[x=-9,y=90,z=140,distance=..20] run particle end_rod -9 89 140 0.1 2.5 0.1 0.02 1 normal