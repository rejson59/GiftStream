execute as @a[x=-64,y=83,z=105,dx=0,dy=1,dz=0] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-64,y=83,z=105,dx=0,dy=1,dz=0] at @s run tp @s ~ ~ ~ 0.0 30.0

execute as @a[x=-57,y=50,z=89,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-51,y=31,z=89,dx=0,dy=10,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-51,y=42,z=89,dx=0,dy=0,dz=0] at @s run effect clear @s
execute as @a[x=-51,y=36,z=89,distance=..20] run particle end_rod -51 36 89 0.1 2.5 0.1 0.02 1 normal

execute unless entity @a[x=-49,y=66,z=91,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -49 64 91 snow_block
execute as @a[x=-49,y=66,z=91,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -49 64 91 redstone_torch

execute if score console lv90timer matches 1.. run scoreboard players remove console lv90timer 1
execute as @e[type=minecart,x=-49,y=66,z=91,distance=..1] run scoreboard players set console lv90timer 50
execute if entity @a[x=-49,y=66,z=91,distance=..10] unless score console lv90timer matches 1.. run summon minecart -49 66 91 {Tags:["lv90minecart"]}

execute as @e[type=minecart,tag=lv90minecart,x=-49,y=66,z=91,distance=1..] at @s unless entity @a[distance=..1,nbt={RootVehicle:{Entity:{id:"minecraft:minecart",Tags:["lv90minecart"]}}}] run kill @s
execute as @e[type=minecart,tag=lv90minecart] at @s unless entity @a[distance=..10] run kill @s

data merge block -64 83 105 {Age:-999999999}
data merge block -64 84 105 {Age:-999999999}