execute unless entity @e[tag=lv100snake] if entity @a[x=-106,y=0,z=43,dx=63,dy=150,dz=63,gamemode=!spectator] run function game:level/snake/lv100/summon
execute unless entity @a[x=-106,y=0,z=43,dx=63,dy=150,dz=63,gamemode=!spectator] if entity @e[tag=lv100snake] run function game:level/snake/lv100/clear

execute if block -79 118 71 light_weighted_pressure_plate unless block -79 118 71 light_weighted_pressure_plate[power=0] as @e[tag=lv100begin] unless entity @e[tag=lv100begin,scores={lv100timer=1..}] at @s run scoreboard players set @s lv100timer 1