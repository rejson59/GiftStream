execute if block -136 92 13 birch_button[powered=true] run scoreboard players set console lv48timer 100
execute if block -136 92 13 birch_button[powered=true] run playsound entity.experience_orb.pickup master @a -136 92 13 2 1
execute if block -136 92 13 birch_button[powered=true] run setblock -136 92 13 birch_button[face=floor,facing=north]
execute if score console lv48timer matches 1.. run scoreboard players remove console lv48timer 1
execute if score console lv48timer matches 1.. run fill -132 83 29 -130 86 29 air destroy
execute unless score console lv48timer matches 1.. run fill -132 83 29 -130 86 29 dark_oak_fence replace