execute if block -36 69 53 warped_button[powered=true] run scoreboard players set console lv83timer 200
execute if score console lv83timer matches 1.. run scoreboard players remove console lv83timer 1
execute if score console lv83timer matches 1.. run setblock -33 78 53 water
execute unless score console lv83timer matches 1.. run setblock -33 78 53 moving_piston