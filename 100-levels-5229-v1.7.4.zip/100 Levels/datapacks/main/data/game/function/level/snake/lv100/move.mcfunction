execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 1.. run scoreboard players add @s lv100timer 1 
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 30.. run scoreboard players set @s lv100timer 0

execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 2..2 as @e[tag=lv100snake,distance=..1.1] at @s unless entity @s[scores={lv100timer=1..}] run scoreboard players set @s lv100timer 1

execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 2 run setblock ~ ~ ~ red_concrete
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 4 run setblock ~ ~ ~ orange_concrete
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 6 run setblock ~ ~ ~ yellow_concrete
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 8 run setblock ~ ~ ~ lime_concrete
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 10 run setblock ~ ~ ~ green_concrete
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 12 run setblock ~ ~ ~ cyan_concrete
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 14 run setblock ~ ~ ~ light_blue_concrete
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 16 run setblock ~ ~ ~ blue_concrete
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 18 run setblock ~ ~ ~ purple_concrete
execute as @e[tag=lv100snake] at @s if score @s lv100timer matches 20 run setblock ~ ~ ~ air

execute as @e[tag=lv100snake] at @s unless score @s lv100timer matches 1.. unless block ~ ~ ~ air run setblock ~ ~ ~ air

schedule function game:level/snake/lv100/move 3t