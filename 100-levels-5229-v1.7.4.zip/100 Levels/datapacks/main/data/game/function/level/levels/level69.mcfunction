execute if score console lv69timer matches 1.. run scoreboard players remove console lv69timer 1
execute if score console lv69timer matches 1 run setblock -55 96 37 acacia_pressure_plate
execute if block -55 96 37 acacia_pressure_plate[powered=true] run scoreboard players set console lv69timer 60
execute if block -55 96 37 acacia_pressure_plate[powered=true] run setblock -55 96 37 air
execute if score console lv69timer matches 60 run fill -57 83 32 -58 83 31 slime_block
execute if score console lv69timer matches 58 run fill -57 84 32 -58 84 31 slime_block
execute if score console lv69timer matches 56 run fill -57 85 32 -58 85 31 slime_block
execute if score console lv69timer matches 54 run fill -57 86 32 -58 86 31 slime_block
execute if score console lv69timer matches 52 run fill -57 87 32 -58 87 31 slime_block replace
execute if score console lv69timer matches 60 run playsound block.slime_block.place master @a -57.0 83 32.0 2 1
execute if score console lv69timer matches 58 run playsound block.slime_block.place master @a -57.0 84 32.0 2 1
execute if score console lv69timer matches 56 run playsound block.slime_block.place master @a -57.0 85 32.0 2 1
execute if score console lv69timer matches 54 run playsound block.slime_block.place master @a -57.0 86 32.0 2 1
execute if score console lv69timer matches 52 run playsound block.slime_block.place master @a -57.0 87 32.0 2 1
execute unless score console lv69timer matches 1.. run fill -57 83 32 -58 88 31 air destroy

execute as @a[x=-61,y=92,z=27,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true