execute as @a[x=-129,y=51,z=60,dx=0,dy=33,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-130,y=83,z=60,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -129 67 60 0.1 10 0.1 0.02 3 normal

execute if block -133 83 60 stone_pressure_plate[powered=true] run fill -134 83 60 -134 84 60 air destroy
execute unless block -133 83 60 stone_pressure_plate[powered=true] run fill -134 83 60 -134 84 60 stone