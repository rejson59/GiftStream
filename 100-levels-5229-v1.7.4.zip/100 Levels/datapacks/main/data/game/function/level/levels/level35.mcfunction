effect give @a[x=-3,y=68,z=88,dx=1,dy=18,dz=1] levitation 1 10 true
effect clear @a[x=-10,y=87,z=87,dx=9,dy=0,dz=9] levitation
particle end_rod -2.0 78.0 89.0 0.4 4 0.4 0.02 2 normal