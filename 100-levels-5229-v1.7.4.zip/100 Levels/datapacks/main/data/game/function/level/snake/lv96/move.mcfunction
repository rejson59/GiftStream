execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 1.. run scoreboard players add @s lv96timer 1 
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 30.. run scoreboard players set @s lv96timer 0

execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 2..2 as @e[tag=lv96snake,distance=..1.1] at @s unless entity @s[scores={lv96timer=1..}] run scoreboard players set @s lv96timer 1

execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 2 run setblock ~ ~ ~ light_blue_concrete
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 4 run setblock ~ ~ ~ cyan_concrete
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 6 run setblock ~ ~ ~ light_blue_concrete
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 8 run setblock ~ ~ ~ cyan_concrete
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 10 run setblock ~ ~ ~ light_blue_concrete
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 12 run setblock ~ ~ ~ cyan_concrete
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 14 run setblock ~ ~ ~ light_blue_concrete
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 16 run setblock ~ ~ ~ cyan_concrete
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 18 run setblock ~ ~ ~ light_blue_concrete
execute as @e[tag=lv96snake] at @s if score @s lv96timer matches 20 run setblock ~ ~ ~ air

execute as @e[tag=lv96snake] at @s unless score @s lv96timer matches 1.. unless block ~ ~ ~ air run setblock ~ ~ ~ air

schedule function game:level/snake/lv96/move 3t