execute as @a[x=-81,y=86,z=18,dx=0,dy=6,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-81,y=95,z=18,dx=0,dy=2,dz=0] at @s run effect clear @s
particle end_rod -81 90 18 0.1 2.2 0.1 0.02 1 normal