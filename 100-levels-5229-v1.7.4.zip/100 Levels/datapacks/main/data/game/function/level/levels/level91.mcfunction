execute as @a[x=-59,y=75,z=65,dx=0,dy=1,dz=0] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-59,y=75,z=65,dx=0,dy=1,dz=0] at @s run tp @s ~ ~ ~ 37.0 30.0

execute as @a[x=-45,y=69,z=74,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true

tag @a remove lv91_portal
execute as @a[x=-58,y=60,z=74,dx=0,dy=3,dz=1] at @s run effect give @s nausea 5 255 true
execute as @a[x=-58,y=60,z=74,dx=0,dy=3,dz=1] at @s run effect give @s slowness 5 255 true
execute as @a[x=-58,y=60,z=74,dx=0,dy=3,dz=1] at @s run effect give @s blindness 5 255 true
execute as @a[x=-58,y=60,z=74,dx=0,dy=3,dz=1] at @s run tag @s add lv91_portal
execute as @a[tag=lv91_portal] at @s run scoreboard players add @s lv91timer 1
execute as @a[scores={lv91timer=1..},tag=!lv91_portal] at @s run scoreboard players remove @s lv91timer 1
execute as @a[scores={lv91timer=20..20},tag=lv91_portal] at @s run playsound block.portal.trigger master @s ~ ~ ~ 1 1
execute as @a[scores={lv91timer=100..},tag=lv91_portal] at @s run effect clear @s
execute as @a[scores={lv91timer=100..},tag=lv91_portal] at @s run playsound block.portal.travel master @s ~ ~ ~ 1 1
execute as @a[scores={lv91timer=100..},tag=lv91_portal] at @s run tp @s -20 19 269 63.0 30.0

data merge block -59 75 65 {Age:-999999999}
data merge block -59 76 65 {Age:-999999999}