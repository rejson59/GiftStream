effect give @a[x=-141,y=89,z=131,dx=0,dy=7,dz=0] levitation 1 3 true
effect clear @a[x=-141,y=97,z=131,dx=0,dy=0,dz=0] levitation
particle end_rod -141 91 131 0.1 1.5 0.1 0.02 1 normal

execute if block -139 87 134 birch_button[powered=true] run scoreboard players set console lv20timer 60
execute if score console lv20timer matches 1.. run scoreboard players remove console lv20timer 1
execute if score console lv20timer matches 1.. run setblock -141 82 134 redstone_torch replace
execute unless score console lv20timer matches 1.. run setblock -141 82 134 dirt replace
