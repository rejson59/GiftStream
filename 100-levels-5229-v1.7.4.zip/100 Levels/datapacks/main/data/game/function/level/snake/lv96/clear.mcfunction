scoreboard players set @e[tag=lv96snake] lv96timer 0
execute as @e[tag=lv96snake] at @s run setblock ~ ~ ~ air
kill @e[tag=lv96snake]
schedule clear game:level/snake/lv96/move