execute as @a[x=-92,y=65,z=14,dx=0,dy=16,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-92,y=82,z=14,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -92 74 14 0.1 4.25 0.1 0.02 2 normal

tag @a remove lv46_portal
execute as @a[x=-87,y=95,z=17,dx=0,dy=2,dz=2] at @s run effect give @s nausea 5 255 true
execute as @a[x=-87,y=95,z=17,dx=0,dy=2,dz=2] at @s run effect give @s slowness 5 255 true
execute as @a[x=-87,y=95,z=17,dx=0,dy=2,dz=2] at @s run effect give @s blindness 5 255 true
execute as @a[x=-87,y=95,z=17,dx=0,dy=2,dz=2] at @s run tag @s add lv46_portal
execute as @a[tag=lv46_portal] at @s run scoreboard players add @s lv46timer 1
execute as @a[scores={lv46timer=1..},tag=!lv46_portal] at @s run scoreboard players remove @s lv46timer 1
execute as @a[scores={lv46timer=100..},tag=lv46_portal] at @s run effect clear @s
execute as @a[scores={lv46timer=100..},tag=lv46_portal] at @s run tp @s -106 32 18 -143.0 30.0