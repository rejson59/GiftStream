execute unless entity @e[tag=lv96snake] if entity @a[x=-81,y=0,z=307,dx=18,dy=69,dz=23,gamemode=!spectator] run function game:level/snake/lv96/summon
execute unless entity @a[x=-81,y=0,z=307,dx=18,dy=69,dz=23,gamemode=!spectator] if entity @e[tag=lv96snake] run function game:level/snake/lv96/clear

execute if block -64 20 310 light_weighted_pressure_plate unless block -64 20 310 light_weighted_pressure_plate[power=0] as @e[tag=lv96begin] unless entity @e[tag=lv96begin,scores={lv96timer=1..}] at @s run scoreboard players set @s lv96timer 1