tag @a remove lv100_portal
execute as @a[x=-50,y=49,z=303,dx=1,dy=2,dz=0] at @s run effect give @s nausea 5 255 true
execute as @a[x=-50,y=49,z=303,dx=1,dy=2,dz=0] at @s run effect give @s slowness 5 255 true
execute as @a[x=-50,y=49,z=303,dx=1,dy=2,dz=0] at @s run effect give @s blindness 5 255 true
execute as @a[x=-50,y=49,z=303,dx=1,dy=2,dz=0] at @s run tag @s add lv100_portal
execute as @a[tag=lv100_portal] at @s run scoreboard players add @s lv100timer2 1
execute as @a[scores={lv100timer2=1..},tag=!lv100_portal] at @s run scoreboard players remove @s lv100timer2 1
execute as @a[scores={lv100timer2=20..20},tag=lv100_portal] at @s run playsound block.portal.trigger master @s ~ ~ ~ 1 1
execute as @a[scores={lv100timer2=100..},tag=lv100_portal] at @s run effect clear @s
execute as @a[scores={lv100timer2=100..},tag=lv100_portal] at @s run playsound block.portal.travel master @s ~ ~ ~ 1 1
execute as @a[scores={lv100timer2=100..},tag=lv100_portal] at @s run tp @s -75 84 76 -90.0 30.0

execute as @a[x=-73,y=107,z=75,dx=0,dy=5,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-73,y=113,z=75,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -73 109.0 75 0.1 1.5 0.1 0.02 1 normal

execute unless entity @a[x=-75,y=115,z=82,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -75 113 82 stone
execute as @a[x=-75,y=115,z=82,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -75 113 82 redstone_torch

execute if score console lv100timer3 matches 1.. run scoreboard players remove console lv100timer3 1
execute as @e[type=minecart,x=-75,y=115,z=82,distance=..1] run scoreboard players set console lv100timer3 50
execute if entity @a[x=-75,y=115,z=82,distance=..10] unless score console lv100timer3 matches 1.. run summon minecart -75 115 82 {Tags:["lv100minecart"]}

execute as @e[type=minecart,tag=lv100minecart,x=-75,y=115,z=82,distance=1..] at @s unless entity @a[distance=..1,nbt={RootVehicle:{Entity:{id:"minecraft:minecart",Tags:["lv100minecart"]}}}] run kill @s
execute as @e[type=minecart,tag=lv100minecart] at @s unless entity @a[distance=..10] run kill @s

execute as @a[x=-69,y=143,z=74,distance=..1.5] run fill -69 142 72 -70 142 74 air destroy
execute as @a[x=-69,y=143,z=74,distance=..1.5] run fill -68 142 73 -68 142 74 air destroy
execute as @a[x=-69,y=143,z=74,distance=..1.5] run setblock -69 142 75 air destroy
execute as @a[x=-69,y=143,z=74,distance=..1.5] run setblock -71 142 73 air destroy
execute unless entity @a[x=-69,y=143,z=74,distance=..1.5] run fill -71 142 72 -68 142 75 cracked_stone_bricks replace air
execute if block -74 140 73 jungle_pressure_plate[powered=true] run fill -75 140 73 -75 141 73 air destroy
execute unless block -74 140 73 jungle_pressure_plate[powered=true] run fill -75 140 73 -75 141 73 stone

execute as @a[x=-73,y=160,z=73,dx=0,dy=8,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-73,y=169,z=73,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -73 164 73 0.1 2 0.1 0.02 1 normal

execute as @a[x=-76,y=178,z=74,distance=..5] at @s run tag @s add end

data merge block -72 176 74 {Age:-999999999}
data merge block -72 177 74 {Age:-999999999}