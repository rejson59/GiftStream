execute as @a[x=-131,y=85,z=77,dx=0,dy=1,dz=0] at @s run effect give @s levitation 3 1 true
particle cloud -131 85 77 0.075 0.1 0.075 0.01 1 normal