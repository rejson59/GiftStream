#execute unless entity @e[tag=lv65slime] run summon minecraft:magma_cube -20 75.7 66 {Tags:["lv65slime"],NoAI:1b,Invulnerable:1b,PersistenceRequired:1b,Silent:1b,NoGravity:1b,Size:6}
execute as @e[type=magma_cube,x=-20,y=75.7,z=66,distance=..3,nbt={Size:2}] at @s run kill @s
execute as @e[type=magma_cube,x=-20,y=75.7,z=66,distance=..3,nbt={Size:0}] at @s run kill @s
team join mob @e[tag=lv65slime]

execute as @a[x=-13,y=96,z=73,dx=0,dy=1,dz=0] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-13,y=96,z=73,dx=0,dy=1,dz=0] at @s run tp @s ~ ~ ~ 155.0 30.0

data merge block -13 96 73 {Age:-999999999}
data merge block -13 97 73 {Age:-999999999}