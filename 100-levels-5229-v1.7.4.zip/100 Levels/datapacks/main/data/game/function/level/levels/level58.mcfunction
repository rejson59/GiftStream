execute as @a[x=-90,y=87,z=136,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-83,y=82,z=129,dx=0,dy=4,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-84,y=86,z=128,dx=2,dy=1,dz=0] at @s run effect clear @s
execute as @a[x=-84,y=86,z=130,dx=2,dy=1,dz=0] at @s run effect clear @s
execute as @a[x=-84,y=86,z=129,dx=0,dy=1,dz=0] at @s run effect clear @s
execute as @a[x=-82,y=86,z=129,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -83 84 129 0.1 1.25 0.1 0.02 1 normal

execute if score console lv58timer matches 1.. run scoreboard players remove console lv58timer 1
execute if block -85 54 135 oak_button[powered=true] run scoreboard players set console lv58timer 60
execute if score console lv58timer matches 1.. run fill -79 48 136 -78 48 137 slime_block
execute unless score console lv58timer matches 1.. run fill -79 48 136 -78 48 136 gravel
execute unless score console lv58timer matches 1.. run fill -79 48 137 -78 48 137 stone

execute as @a[x=-74,y=45,z=125,dx=-11,dy=0,dz=12] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-74,y=45,z=125,dx=-11,dy=0,dz=12] at @s run tp @s -84 47 126 -90.0 30.0

execute as @a[x=-68,y=30,z=128,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true

execute if score console lv58timer2 matches 1.. run scoreboard players remove console lv58timer2 1
execute if block -70 16 134 stone_button[powered=true] run scoreboard players set console lv58timer2 40
execute if score console lv58timer2 matches 1.. run fill -72 12 136 -72 13 136 air destroy 
execute unless score console lv58timer2 matches 1.. run fill -72 12 136 -72 13 136 cobblestone

execute as @a[x=-72,y=12,z=137,dx=0,dy=1,dz=0] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-72,y=12,z=137,dx=0,dy=1,dz=0] at @s run tp @s ~ ~ ~ -90.0 30.0

execute as @a[x=-68,y=21,z=131,dx=0,dy=55,dz=0] at @s run effect give @s levitation 1 24 true
execute as @a[x=-67,y=75,z=131,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -68 50 131 0.1 12.5 0.1 0.02 5 normal

execute unless entity @a[x=-81,y=18,z=128,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -81 16 128 stone
execute as @a[x=-81,y=18,z=128,distance=..2,nbt={RootVehicle:{Entity:{id:"minecraft:minecart"}}}] run setblock -81 16 128 redstone_torch

execute if score console lv58timer3 matches 1.. run scoreboard players remove console lv58timer3 1
execute as @e[type=minecart,x=-81,y=18,z=128,distance=..1] run scoreboard players set console lv58timer3 50
execute if entity @a[x=-81,y=18,z=128,distance=..10] unless score console lv58timer3 matches 1.. run summon minecart -81 18 128 {Tags:["lv58minecart"]}

execute as @e[type=minecart,tag=lv58minecart,x=-81,y=18,z=128,distance=1..] at @s unless entity @a[distance=..1,nbt={RootVehicle:{Entity:{id:"minecraft:minecart",Tags:["lv58minecart"]}}}] run kill @s
execute as @e[type=minecart,tag=lv58minecart] at @s unless entity @a[distance=..10] run kill @s

data merge block -72 12 137 {Age:-999999999}
data merge block -72 13 137 {Age:-999999999}