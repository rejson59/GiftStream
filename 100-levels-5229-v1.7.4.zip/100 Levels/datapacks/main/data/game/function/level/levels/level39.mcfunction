effect give @a[x=-3,y=83,z=44,dx=0,dy=12,dz=0] levitation 1 10 true
effect clear @a[x=-3,y=96,z=44,dx=0,dy=1,dz=0] levitation
particle end_rod -3 89 44 0.1 4 0.1 0.02 2 normal