execute as @a[x=-84,y=77,z=45,dx=2,dy=0,dz=2] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-69,y=69,z=60,dx=0,dy=19,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-70,y=87,z=60,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -69 78.5 60 0.1 5 0.1 0.02 1 normal