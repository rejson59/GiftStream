execute unless entity @a[x=-29,y=91,z=7,distance=..4] run setblock -29 90 7 farmland[moisture=7]
execute unless entity @a[x=-29,y=91,z=7,distance=..4] run setblock -29 91 7 wheat[age=7]

execute positioned -29 91 7 if entity @a[x=-29,y=91,z=7,distance=..4] unless block ~ ~ ~ hay_block run playsound block.grass.place master @a ~ ~ ~ 1 1
execute positioned -29 91 7 if entity @a[x=-29,y=91,z=7,distance=..4] unless block ~ ~ ~ hay_block run particle happy_villager ~ ~ ~ 0.5 0.5 0.5 0.3 30
execute positioned -29 91 7 if entity @a[x=-29,y=91,z=7,distance=..4] unless block ~ ~ ~ hay_block run setblock -29 91 7 hay_block

execute as @a[x=-19,y=94,z=3,dx=0,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true