execute as @a[x=-45,y=85,z=147,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true
execute as @a[x=-53,y=90,z=139,dx=9,dy=2,dz=9] at @s if block ~ ~ ~ water run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-53,y=90,z=139,dx=9,dy=2,dz=9] at @s if block ~ ~ ~ seagrass run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-53,y=90,z=139,dx=9,dy=2,dz=9] at @s if block ~ ~ ~ water run tp @s -52 93 147 -123.0 30.0
execute as @a[x=-53,y=90,z=139,dx=9,dy=2,dz=9] at @s if block ~ ~ ~ seagrass run tp @s -52 93 147 -123.0 30.0