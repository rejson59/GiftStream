execute as @a[x=-97,y=36,z=64,dx=0,dy=35,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-96,y=70,z=64,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -97 54.0 64 0.1 8 0.1 0.02 3 normal

execute as @a[x=-91,y=81,z=66,dx=0,dy=7,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-91,y=89,z=66,dx=0,dy=0,dz=0] at @s run effect clear @s
particle end_rod -91 84.5 66 0.1 2 0.1 0.02 1 normal

execute as @a[x=-105,y=87,z=80,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-102,y=84,z=77,dx=0,dy=1,dz=0] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1 1
execute as @a[x=-102,y=84,z=77,dx=0,dy=1,dz=0] at @s run tp @s ~ ~ ~ -90.0 30.0

execute as @a[x=-106,y=65,z=63,dx=18,dy=2,dz=18] at @s if block ~ ~ ~ water run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1 1
execute as @a[x=-106,y=65,z=63,dx=18,dy=2,dz=18] at @s if block ~ ~ ~ water run tp @s -96 70 64 -70.0 30.0

data merge block -102 84 77 {Age:-999999999}
data merge block -102 85 77 {Age:-999999999}