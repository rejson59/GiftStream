execute as @a[x=-39,y=70,z=109,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-39,y=68,z=120,dx=1,dy=6,dz=1] at @s run effect give @s levitation 1 12 true
execute as @a[x=-39,y=75,z=120,dx=1,dy=0,dz=1] at @s run effect clear @s
particle end_rod -38.0 71.5 121.0 0.5 1.5 0.5 0.02 1 normal