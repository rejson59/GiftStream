execute as @a[x=-19,y=19,z=293,dx=0,dy=10,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-19,y=28,z=294,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -19 24 293 0.1 3 0.1 0.02 1 normal

execute as @a[x=-33,y=20,z=303,dx=1,dy=0,dz=1] at @s run effect give @s slow_falling 1 1 true