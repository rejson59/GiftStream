execute if block -9 95 84 birch_button[powered=true] run scoreboard players set console lv36timer 40
execute if score console lv36timer matches 1.. run scoreboard players remove console lv36timer 1
execute if score console lv36timer matches 1.. run fill -7 87 75 -4 87 79 air destroy
execute if score console lv36timer matches 1.. run fill -6 87 74 -5 87 80 air destroy
execute unless score console lv36timer matches 1.. run fill -7 87 75 -4 87 79 lime_stained_glass replace
execute unless score console lv36timer matches 1.. run fill -6 87 74 -5 87 80 lime_stained_glass replace

execute as @a[x=-7,y=66,z=74,dx=3,dy=0,dz=6] at @s run scoreboard players add @s lv36timer2 1
execute as @a[scores={lv36timer2=10..10}] at @s run tp @s -10 95 85 -135.0 30.0
execute as @a[scores={lv36timer2=10..10}] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[scores={lv36timer2=10..10}] at @s run scoreboard players set @s lv36timer2 0
execute as @a[x=-7,y=85,z=74,dx=3,dy=0,dz=6] at @s run scoreboard players set @s lv36timer2 0
execute as @a[x=-6,y=79,z=72,dx=1,dy=2,dz=0] at @s run scoreboard players set @s lv36timer2 0