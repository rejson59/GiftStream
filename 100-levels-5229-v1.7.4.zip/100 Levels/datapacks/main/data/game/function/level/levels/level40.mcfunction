execute as @a[x=-2,y=70,z=30,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true

effect give @a[x=-2,y=81,z=13,dx=0,dy=17,dz=0] levitation 1 10 true
effect clear @a[x=-2,y=97,z=14,dx=0,dy=1,dz=0] levitation
particle end_rod -2 90 13 0.1 4.5 0.1 0.02 2 normal