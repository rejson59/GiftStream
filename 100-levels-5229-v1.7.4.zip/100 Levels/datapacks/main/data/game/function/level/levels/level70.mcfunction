execute if score console lv70timer matches 1.. run scoreboard players remove console lv70timer 1
execute if block -69 87 34 birch_button[powered=true] run scoreboard players set console lv70timer 200
execute if score console lv70timer matches 161..200 run setblock -71 86 39 redstone_block replace
execute if score console lv70timer matches 151..190 run setblock -74 86 39 redstone_block replace
execute if score console lv70timer matches 11..50 run setblock -75 91 39 redstone_block replace
execute if score console lv70timer matches 1..40 run setblock -72 92 39 redstone_block replace
execute unless score console lv70timer matches 161..200 run setblock -71 86 39 white_terracotta replace
execute unless score console lv70timer matches 151..190 run setblock -74 86 39 white_terracotta replace
execute unless score console lv70timer matches 11..50 run setblock -75 91 39 white_terracotta replace
execute unless score console lv70timer matches 1..40 run setblock -72 92 39 white_terracotta replace
execute if block -69 87 34 birch_button[powered=true] run setblock -69 87 34 birch_button[face=floor,powered=false,facing=south]

execute as @a[x=-78,y=90,z=40,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true