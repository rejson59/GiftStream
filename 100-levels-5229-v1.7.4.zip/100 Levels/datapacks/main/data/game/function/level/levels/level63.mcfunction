execute as @a[x=-13,y=61,z=98,dx=0,dy=12,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-13,y=74,z=98,dx=0,dy=0,dz=0] at @s run effect clear @s
execute as @a[x=-13,y=67,z=98,distance=..20] run particle end_rod -13 67 98 0.1 3 0.1 0.02 1 normal

execute if score console lv63timer matches 1.. run scoreboard players remove console lv63timer 1
execute as @a[x=-15,y=50,z=100,distance=..2] unless score console lv63timer matches 1.. run scoreboard players set console lv63timer 100
execute if score console lv63timer matches 1.. run fill -18 68 103 -18 70 103 air destroy
execute if score console lv63timer matches 100 run kill @e[tag=lv63fb]
execute if score console lv63timer matches 100 run fill -18 48 103 -18 50 103 air destroy
execute if score console lv63timer matches 100 run playsound block.glass.break master @a -15 50 100 1 0.8 0
execute if score console lv63timer matches 100 run summon minecraft:falling_block -18 68 103 {Tags:["lv63fb"],Time:1,BlockState:{Name:"minecraft:blue_ice"}}
execute if score console lv63timer matches 100 run summon minecraft:falling_block -18 69 103 {Tags:["lv63fb"],Time:1,BlockState:{Name:"minecraft:blue_ice"}}
execute if score console lv63timer matches 100 run summon minecraft:falling_block -18 70 103 {Tags:["lv63fb"],Time:1,BlockState:{Name:"minecraft:blue_ice"}}
execute unless score console lv63timer matches 1.. run fill -18 68 103 -18 70 103 blue_ice replace
execute unless score console lv63timer matches 1.. run fill -18 48 103 -18 50 103 air destroy