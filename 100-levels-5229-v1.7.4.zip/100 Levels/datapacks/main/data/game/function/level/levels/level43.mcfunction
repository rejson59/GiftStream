execute as @a[x=-59,y=80,z=12,dx=12,dy=4,dz=12] at @s if block ~ ~ ~ water run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-59,y=80,z=12,dx=12,dy=4,dz=12] at @s if block ~ ~ ~ water run tp @s -47 87 15 36.0 30.0

execute as @a[x=-49,y=88,z=23,dx=0,dy=9,dz=0] at @s run effect give @s levitation 1 12 true
execute as @a[x=-50,y=96,z=23,dx=0,dy=1,dz=0] at @s run effect clear @s
particle end_rod -49 93 23 0.1 2 0.1 0.02 1 normal