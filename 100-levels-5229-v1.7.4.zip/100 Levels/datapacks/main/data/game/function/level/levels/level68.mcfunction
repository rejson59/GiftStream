execute as @a[x=-27,y=90,z=31,dx=1,dy=0,dz=2] at @s run effect give @s slow_falling 1 1 true

execute positioned -38 83 39 if entity @a[x=-38,y=83,z=39,distance=..4] unless block ~ ~ ~ nether_wart_block run playsound block.wart_block.place master @a ~ ~ ~ 1 1
execute positioned -38 83 39 if entity @a[x=-38,y=83,z=39,distance=..4] unless block ~ ~ ~ nether_wart_block run setblock ~ ~ ~ nether_wart_block replace
execute unless entity @a[x=-38,y=83,z=39,distance=..4] run setblock -38 83 39 nether_wart[age=3] replace