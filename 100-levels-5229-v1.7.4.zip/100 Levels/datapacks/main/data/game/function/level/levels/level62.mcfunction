execute as @a[x=-16,y=90,z=122,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true

execute as @a[x=-13,y=70,z=112,dx=0,dy=0,dz=0] at @s run effect give @s slow_falling 1 1 true