execute as @a[x=-7,y=92,z=62,dx=1,dy=1,dz=1] run scoreboard players set console lv37timer 30
execute if score console lv37timer matches 1.. run fill -7 96 62 -6 96 63 air destroy
execute unless score console lv37timer matches 1.. run fill -7 96 62 -6 96 63 orange_stained_glass replace
execute if score console lv37timer matches 1.. run scoreboard players remove console lv37timer 1

effect give @a[x=-7,y=90,z=62,dx=1,dy=0,dz=1] jump_boost 1 7 true
effect give @a[x=-7,y=90,z=62,dx=1,dy=0,dz=1] slow_falling 1 1 true
particle end_rod -6.0 93.0 63.0 0.5 1.5 0.5 0.02 1 normal
effect clear @a[x=-5,y=90,z=62,dx=0,dy=1,dz=0]

execute as @a[x=-10,y=86,z=62,dx=1,dy=0.5,dz=3] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-10,y=86,z=58,dx=4,dy=0.5,dz=2] at @s run playsound entity.enderman.teleport master @s ~ ~ ~ 9999 1
execute as @a[x=-10,y=86,z=62,dx=1,dy=0.5,dz=3] at @s run tp @s -8 88 66 135.0 30.0
execute as @a[x=-10,y=86,z=58,dx=4,dy=0.5,dz=2] at @s run tp @s -8 88 66 135.0 30.0