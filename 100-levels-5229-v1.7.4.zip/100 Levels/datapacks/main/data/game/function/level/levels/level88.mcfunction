execute as @a[x=-91,y=67,z=91,dx=1,dy=20,dz=1] at @s run effect give @s levitation 1 12 true
execute as @a[x=-91,y=88,z=91,dx=1,dy=1,dz=1] at @s run effect clear @s
particle end_rod -90.0 77.5 92.0 0.4 5 0.4 0.02 2 normal