function game:lobby/tick
function game:level/tick

kill @e[type=tnt,tag=!ingame]

execute positioned -104 85 113 run function common:ingame/checkpoint/checkpoint/active
execute positioned -79 116 71 run function common:ingame/checkpoint/checkpoint/active
